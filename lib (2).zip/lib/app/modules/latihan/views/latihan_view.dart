import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/latihan_controller.dart';
import 'package:silat_mastery_app_2/app/widget/latihan/latihancard.dart';

class LatihanView extends GetView<LatihanController> {
  const LatihanView({super.key});

  @override
  Widget build(BuildContext context) {
    final dataLatihan = controller.dataLatihan.value ?? {};

    return Scaffold(
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }

        final totalDurasi = controller.daftarLatihan.fold<int>(
          0,
          (sum, item) => sum + ((item['durasi'] ?? 0) as int),
        );
        final totalLatihan = controller.daftarLatihan.length;

        return Column(
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(24),
                bottomRight: Radius.circular(24),
              ),
              child: Image.network(
                dataLatihan['gambar'] ?? '',
                width: double.infinity,
                height: 180,
                fit: BoxFit.cover,
                errorBuilder:
                    (context, error, stackTrace) => Container(
                      height: 180,
                      color: Colors.grey,
                      alignment: Alignment.center,
                      child: const Icon(Icons.broken_image),
                    ),
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildInfo("Durasi", "$totalDurasi Menit"),
                  _buildInfo("Latihan", "$totalLatihan"),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "Latihan",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: controller.daftarLatihan.length,
                itemBuilder: (context, index) {
                  final gerakan = controller.daftarLatihan[index];
                  return LatihanCard(
                    namaGerakan: gerakan['nama_gerakan'] ?? '-',
                    gambar: gerakan['gambar'] ?? '',
                    repetisi: gerakan['repetisi'],
                    durasi: gerakan['durasi'],
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red[900],
                  minimumSize: const Size.fromHeight(50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text("MULAI", style: TextStyle(fontSize: 16)),
              ),
            ),
          ],
        );
      }),
    );
  }

  Widget _buildInfo(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        Text(label),
      ],
    );
  }
}
