import 'package:flutter/material.dart';
import 'package:silat_mastery_app_2/app/services/api_service.dart';

class LatihanCard extends StatelessWidget {
  final String namaGerakan;
  final String gambar;
  final int? repetisi;
  final int? durasi;

  const LatihanCard({
    super.key,
    required this.namaGerakan,
    required this.gambar,
    this.repetisi,
    this.durasi,
  });

  // Fungsi untuk membentuk URL gambar
  String getImageUrl(String gambarPath) {
    if (gambarPath.isEmpty) {
      return "${ApiService.baseUrl}/upload/gerakan/placeholder.png";
    }

    final fileName = gambarPath.split('/').last;
    return "${ApiService.baseUrl}/upload/gerakan/$fileName";
  }

  @override
  Widget build(BuildContext context) {
    // Teks keterangan, bisa xRepetisi atau durasi
    String detailText = '';
    if (repetisi != null && repetisi! > 0) {
      detailText = 'x$repetisi';
    } else if (durasi != null && durasi! > 0) {
      detailText = '$durasi detik';
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          const Padding(
            padding: EdgeInsets.only(right: 12),
            child: Icon(Icons.drag_indicator, color: Colors.grey),
          ),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.network(
              getImageUrl(gambar),
              width: 50,
              height: 70,
              fit: BoxFit.cover,
              errorBuilder:
                  (context, error, stackTrace) =>
                      const Icon(Icons.image_not_supported),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  namaGerakan,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                if (detailText.isNotEmpty)
                  Text(
                    detailText,
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
