import 'dart:async';
import 'package:get/get.dart';

class LatihanV1Controller extends GetxController {
  final gerakan = <String, dynamic>{}.obs;
  final totalCountdown = 20;
  final countdown = 20.obs;
  Timer? timer;

  @override
  void onInit() {
    super.onInit();
    final args = Get.arguments as Map<String, dynamic>?;

    if (args != null) {
      gerakan.assignAll(args);
      startCountdown();
    } else {
      Get.snackbar('Error', 'Data gerakan tidak ditemukan');
    }
  }

  void startCountdown() {
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (countdown.value <= 1) {
        t.cancel();
        Get.toNamed('/latihan-v2', arguments: gerakan);
      } else {
        countdown.value--;
      }
    });
  }

  @override
  void onClose() {
    timer?.cancel();
    super.onClose();
  }
}
