import 'dart:async';
import 'package:get/get.dart';

class LatihanV2Controller extends GetxController {
  final gerakan = <String, dynamic>{}.obs;
  final timerValue = 0.obs;
  final isRunning = true.obs;
  Timer? timer;
  final indexGerakan = 0.obs;

  @override
  void onInit() {
    super.onInit();
    final args = Get.arguments as Map<String, dynamic>?;

    if (args != null) {
      gerakan.assignAll(args);
indexGerakan.value = args['index'] ?? 0;
      final durasi = gerakan['durasi'] ?? 0;
      if (durasi > 0) {
        timerValue.value = durasi;
        startTimer();
      }
    } else {
      Get.snackbar('Error', 'Data gerakan tidak ditemukan');
    }
  }

  void startTimer() {
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (timerValue.value <= 1) {
        t.cancel();
        timerValue.value = 0;
        isRunning.value = false;
      } else {
        timerValue.value--;
      }
    });
  }

  void pauseOrResume() {
    if (isRunning.value) {
      timer?.cancel();
    } else {
      startTimer();
    }
    isRunning.toggle();
  }

  @override
  void onClose() {
    timer?.cancel();
    super.onClose();
  }
}
