import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:silat_mastery_app_2/app/widget/form/app_primary_button.dart';
import '../controllers/latihan_controller.dart';
import 'package:silat_mastery_app_2/app/widget/latihan/latihancard.dart';

class LatihanView extends GetView<LatihanController> {
  const LatihanView({super.key});

  @override
  Widget build(BuildContext context) {
    final dataLatihan = controller.dataLatihan.value ?? {};

    return Scaffold(
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }

        final totalDurasi = controller.dataLatihan.value?['durasi'] ?? 0;
        final totalLatihan = controller.dataLatihan.value?['jumlah'] ?? 0;

        return Column(
          children: [
            Stack(
              children: [
                Image.network(
                  dataLatihan['gambar'] ?? '',
                  width: double.infinity,
                  height: 250,
                  fit: BoxFit.cover,
                  errorBuilder:
                      (context, error, stackTrace) => Container(
                        height: 250,
                        color: Colors.grey,
                        alignment: Alignment.center,
                        child: const Icon(Icons.broken_image),
                      ),
                ),
                Positioned(
                  top: 40,
                  left: 16,
                  child: CircleAvatar(
                    backgroundColor: Colors.white.withOpacity(0.8),
                    child: IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.black),
                      onPressed: () => Get.back(),
                    ),
                  ),
                ),
                Positioned(
                  top: 40,
                  right: 16,
                  child: CircleAvatar(
                    backgroundColor: Colors.white.withOpacity(0.8),
                    child: IconButton(
                      icon: const Icon(Icons.more_vert, color: Colors.black),
                      onPressed: () {},
                    ),
                  ),
                ),
              ],
            ),

            Expanded(
              child: Transform.translate(
                offset: const Offset(0, -36),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, -2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Text(
                          dataLatihan['judul']?.toUpperCase() ?? "HARI",
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.2,
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          _infoBox("Durasi", "$totalDurasi Menit"),
                          const SizedBox(width: 12),
                          _infoBox("Latihan", "$totalLatihan"),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Expanded(
                        child: ReorderableListView(
                          onReorder: (oldIndex, newIndex) {
                            if (newIndex > oldIndex) newIndex -= 1;
                            final item = controller.daftarLatihan.removeAt(
                              oldIndex,
                            );
                            controller.daftarLatihan.insert(newIndex, item);
                          },
                          children: List.generate(
                            controller.daftarLatihan.length,
                            (index) {
                              final gerakan = controller.daftarLatihan[index];
                              return LatihanCard(
                                key: ValueKey(gerakan['nama_gerakan'] ?? index),
                                index: index,
                                namaGerakan: gerakan['nama_gerakan'] ?? '-',
                                gambar: gerakan['gambar'] ?? '',
                                repetisi: gerakan['repetisi'],
                                durasi: gerakan['durasi'],
                              );
                            },
                          ),
                        ),
                      ),

                      AppPrimaryButton(
                        label: 'Mulai',
                        onPressed: () {
                          // Aksi saat tombol ditekan
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      }),
    );
  }

  Widget _infoBox(String title, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: Colors.grey.shade100,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          children: [
            Text(
              value,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(title, style: const TextStyle(fontSize: 14)),
          ],
        ),
      ),
    );
  }
}
