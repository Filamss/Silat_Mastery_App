import 'package:get/get.dart';
import 'package:silat_mastery_app_2/app/services/api_service.dart';

class LatihanController extends GetxController {
  final daftarLatihan = <Map<String, dynamic>>[].obs;
  final isLoading = false.obs;

  // Data latihan dari halaman sebelumnya
  final dataLatihan = Rxn<Map<String, dynamic>>();

  @override
  void onInit() {
    dataLatihan.value = Get.arguments as Map<String, dynamic>?;
    fetchLatihan();
    super.onInit();
  }

  void fetchLatihan() async {
    isLoading.value = true;
    final hasil = await ApiService.getDaftarGerakan();
    daftarLatihan.value = hasil;
    isLoading.value = false;
  }
}