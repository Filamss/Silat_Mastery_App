import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../controllers/jelajah_controller.dart';

class JelajahView extends GetView<JelajahController> {
  const JelajahView({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('JelajahView'),
        centerTitle: true,
      ),
      body: const Center(
        child: Text(
          'JelajahView is working',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
