import 'package:flutter/material.dart';
import 'package:silat_mastery_app_2/app/services/api_service.dart';
import 'package:cached_network_image/cached_network_image.dart';

class LatihanCard extends StatelessWidget {
  final String namaGerakan;
  final String gambar;
  final int? repetisi;
  final int? durasi;
  final int index; // 👈 Tambah index

  const LatihanCard({
    super.key,
    required this.namaGerakan,
    required this.gambar,
    this.repetisi,
    this.durasi,
    required this.index, // 👈 Wajib untuk drag listener
  });

  String getImageUrl(String gambarPath) {
    if (gambarPath.isEmpty) {
      return "${ApiService.baseUrl}/upload/gerakan/placeholder.png";
    }
    final fileName = gambarPath.split('/').last;
    return "${ApiService.baseUrl}/upload/gerakan/$fileName";
  }

  @override
  Widget build(BuildContext context) {
    String detailText = '';
    if (repetisi != null && repetisi! > 0) {
      detailText = 'x$repetisi';
    } else if (durasi != null && durasi! > 0) {
      detailText = '$durasi detik';
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          // 👇 Hanya ini yang bisa didrag
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: ReorderableDragStartListener(
              index: index,
              child: const Icon(Icons.drag_indicator, color: Colors.grey),
            ),
          ),
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: CachedNetworkImage(
              imageUrl: getImageUrl(gambar),
              width: 50,
              height: 70,
              fit: BoxFit.cover,
              placeholder:
                  (context, url) =>
                      const CircularProgressIndicator(strokeWidth: 2),
              errorWidget:
                  (context, url, error) =>
                      const Icon(Icons.image_not_supported),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  namaGerakan,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                if (detailText.isNotEmpty)
                  Text(
                    detailText,
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
