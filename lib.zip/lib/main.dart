import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:silat_mastery_app_2/app/widget/tema/app_tema.dart';
import 'app/routes/app_pages.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await GetStorage.init();
  await Firebase.initializeApp();
  await initializeDateFormatting;
  ('id_ID', null);
  runApp(const SilatMasteryApp());
}

class SilatMasteryApp extends StatelessWidget {
  const SilatMasteryApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Silat Mastery',
      theme: AppTheme.light, // 🔥 gunakan file terpisah
      initialRoute: Routes.SPLASH,
      getPages: AppPages.routes,
    );
  }
}
