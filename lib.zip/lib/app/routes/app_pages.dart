import 'package:get/get.dart';

import '../modules/biodata_jk/bindings/biodata_jk_binding.dart';
import '../modules/biodata_jk/views/biodata_jk_view.dart';
import '../modules/biodata_tinggi_berat/bindings/biodata_tinggi_berat_binding.dart';
import '../modules/biodata_tinggi_berat/views/biodata_tinggi_berat_view.dart';
import '../modules/biodata_umur/bindings/biodata_umur_binding.dart';
import '../modules/biodata_umur/views/biodata_umur_view.dart';
import '../modules/home/bindings/home_binding.dart';
import '../modules/home/views/home_view.dart';
import '../modules/info/bindings/info_binding.dart';
import '../modules/info/views/info_view.dart';
import '../modules/laporan/bindings/laporan_binding.dart';
import '../modules/laporan/views/laporan_view.dart';
import '../modules/login/bindings/login_binding.dart';
import '../modules/login/views/login_view.dart';
import '../modules/otp_verifikasi/bindings/otp_verifikasi_binding.dart';
import '../modules/otp_verifikasi/views/otp_verifikasi_view.dart';
import '../modules/register/bindings/register_binding.dart';
import '../modules/register/views/register_view.dart';
import '../modules/splash/bindings/splash_binding.dart';
import '../modules/splash/views/splash_view.dart';

part 'app_routes.dart';

class AppPages {
  AppPages._();

  static const INITIAL = Routes.SPLASH;

  static final routes = [
    GetPage(
      name: _Paths.SPLASH,
      page: () => SplashView(),
      binding: SplashBinding(),
    ),
    GetPage(name: _Paths.INFO, page: () => InfoView(), binding: InfoBinding()),
    GetPage(name: _Paths.HOME, page: () => HomeView(), binding: HomeBinding()),
    GetPage(
      name: _Paths.LOGIN,
      page: () => LoginView(),
      binding: LoginBinding(),
    ),
    GetPage(
      name: _Paths.REGISTER,
      page: () => RegisterView(),
      binding: RegisterBinding(),
    ),
    GetPage(
      name: _Paths.OTP_VERIFIKASI,
      page: () => OtpVerifikasiView(),
      binding: OtpVerifikasiBinding(),
    ),
    GetPage(
      name: _Paths.BIODATA_JK,
      page: () => BiodataJkView(),
      binding: BiodataJkBinding(),
    ),
    GetPage(
      name: _Paths.BIODATA_UMUR,
      page: () => BiodataUmurView(),
      binding: BiodataUmurBinding(),
    ),
    GetPage(
      name: _Paths.BIODATA_TINGGI_BERAT,
      page: () => BiodataTinggiBeratView(),
      binding: BiodataTinggiBeratBinding(),
    ),
    GetPage(
      name: _Paths.LAPORAN,
      page: () => LaporanView(),
      binding: LaporanBinding(),
    ),
  ];
}
