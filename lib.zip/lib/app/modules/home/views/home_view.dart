import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:silat_mastery_app_2/app/widget/home/item_latihan_card.dart';
import 'package:silat_mastery_app_2/app/widget/home/target_mingguan_card.dart';
import 'package:silat_mastery_app_2/app/widget/komponen/navbar_bawah.dart';
import '../controllers/home_controller.dart';
import 'package:silat_mastery_app_2/app/widget/tema/app_gaya_teks.dart';
import 'package:silat_mastery_app_2/app/widget/tema/app_warna.dart';
import 'package:silat_mastery_app_2/app/widget/tema/app_spasi.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  final HomeController controller = Get.put(HomeController());
  int currentIndex = 0;

  @override
  void initState() {
    super.initState();
    initializeDateFormatting('id_ID', null);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      bottomNavigationBar: NavbarBawah(
        currentIndex: currentIndex,
        onTap: (index) {
          if (index == 2) {
            // Navigasi ke halaman laporan
            Get.toNamed('/laporan');
          } else {
            setState(() {
              currentIndex = index;
            });
          }
        },
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: AppSpasi.paddingLayar,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 🔥 Logo & Judul
              Row(
                children: [
                  const Icon(
                    Icons.local_fire_department,
                    color: AppWarna.utama,
                    size: 28,
                  ),
                  const SizedBox(width: 8),
                  Text("SILAT MASTERY", style: AppGayaTeks.judul),
                ],
              ),
              AppSpasi.sedang,

              // 📊 Statistik
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: const [
                  _StatBox(title: "LATIHAN", value: "9"),
                  _StatBox(title: "KKAL", value: "1038"),
                  _StatBox(title: "MENIT", value: "54"),
                ],
              ),
              AppSpasi.sedang,

              // 🎯 Target Mingguan (pakai data dari controller)
              TargetMingguanCard(controller: controller),

              AppSpasi.sedang,

              // 🎚️ Kategori Filter
              Obx(
                () => SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: List.generate(controller.kategori.length, (i) {
                      final isSelected = controller.selectedKategori.value == i;
                      return Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ElevatedButton(
                          onPressed:
                              () => controller.selectedKategori.value = i,
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                isSelected
                                    ? AppWarna.utama
                                    : Colors.grey.shade200,
                            foregroundColor:
                                isSelected ? Colors.white : Colors.black,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                          child: Text(controller.kategori[i]),
                        ),
                      );
                    }),
                  ),
                ),
              ),
              AppSpasi.sedang,

              // 🥋 Daftar Latihan
              Obx(
                () => Column(
                  children:
                      controller.filteredLatihan.map((latihan) {
                        return ItemLatihanCard(data: latihan);
                      }).toList(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatBox extends StatelessWidget {
  final String title;
  final String value;

  const _StatBox({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value, style: AppGayaTeks.subJudul),
        AppSpasi.kecil,
        Text(title, style: AppGayaTeks.keterangan.copyWith(color: Colors.grey)),
      ],
    );
  }
}
