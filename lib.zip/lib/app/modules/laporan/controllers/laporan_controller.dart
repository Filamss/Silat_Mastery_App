import 'package:get/get.dart';

class LaporanController extends GetxController {
  var laporanList = [].obs;

  @override
  void onInit() {
    super.onInit();
    fetchLaporan();
  }

  void fetchLaporan() {
    // Contoh data dummy
    laporanList.value = [
      {'judul': 'Laporan Minggu Ini', 'bmi': 21.5, 'berat': 60},
      {'judul': 'Laporan Bulan Lalu', 'bmi': 22.1, 'berat': 62},
    ];
  }
}
