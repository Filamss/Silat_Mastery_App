import 'dart:async';
import 'package:get/get.dart';

class LatihanV2Controller extends GetxController {
  final gerakan = <String, dynamic>{}.obs;
  final timerValue = 0.obs;
  final isRunning = true.obs;
  Timer? timer;
  final indexGerakan = 0.obs;

  List<Map<String, dynamic>> daftarLatihan = [];

  @override
  void onInit() {
    super.onInit();
    final args = Get.arguments as Map<String, dynamic>?;

    if (args != null) {
      gerakan.assignAll(args['gerakan'] ?? {});
      indexGerakan.value = args['index'] ?? 0;
      daftarLatihan = List<Map<String, dynamic>>.from(
        args['daftarLatihan'] ?? [],
      );

      final durasi = gerakan['durasi'] ?? 0;
      if (durasi > 0) {
        timerValue.value = durasi;
        startTimer();
      }
    } else {
      Get.snackbar('Error', 'Data gerakan tidak ditemukan');
    }
  }

  void startTimer() {
    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (timerValue.value <= 1) {
        t.cancel();
        timerValue.value = 0;
        isRunning.value = false;
      } else {
        timerValue.value--;
      }
    });
  }

  void pauseOrResume() {
    if (isRunning.value) {
      timer?.cancel();
    } else {
      startTimer();
    }
    isRunning.toggle();
  }

  void keGerakanSelanjutnya() {
    final nextIndex = indexGerakan.value + 1;
    if (nextIndex < daftarLatihan.length) {
      final nextGerakan = daftarLatihan[nextIndex];
      Get.delete<LatihanV2Controller>();
      Get.offNamed(
        '/latihan-v2',
        arguments: {
          'gerakan': nextGerakan,
          'daftarLatihan': daftarLatihan,
          'index': nextIndex,
        },
      );
    } else {
      Get.back(); // atau arahkan ke halaman selesai
    }
  }

  void keGerakanSebelumnya() {
    final prevIndex = indexGerakan.value - 1;
    if (prevIndex >= 0 && daftarLatihan.isNotEmpty) {
      final prevGerakan = daftarLatihan[prevIndex];
      Get.delete<LatihanV2Controller>();
      Get.offNamed(
        '/latihan-v2',
        arguments: {
          'gerakan': prevGerakan,
          'daftarLatihan': daftarLatihan,
          'index': prevIndex,
        },
      );
    }
  }

  @override
  void onClose() {
    timer?.cancel(); //reset Timer
    super.onClose();
  }
}
